class OrganizerEnitity {
  late String name;
  late String imagePath;

  OrganizerEnitity(String nam, String image) {
    name = nam;
    imagePath = image;
  }
}
